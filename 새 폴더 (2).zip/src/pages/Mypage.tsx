import MyPage from "../components/myPage/Mypage"

const MypagePage = () => {
  return <MyPage />;
}

export default MypagePage;
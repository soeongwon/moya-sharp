import styled from "@emotion/styled";
import { useNewsCommon } from "../../../News/hooks/useNewCommon";

const Bookmark = ({ article }: any) => {
  const { isBookmark, setIsbookmark, addBookmark, deleteBookmark } =
    useNewsCommon();

  function bookmarkEventbind(isBookmarked: boolean) {
    setIsbookmark(!isBookmark);
    if (isBookmarked) {
      addBookmark(article);
    } else {
      deleteBookmark(article);
    }
  }
  return (
    <Button
      isBookmark={isBookmark}
      role="button"
      className="bookmark"
      onClick={() => bookmarkEventbind(!isBookmark)}
    ></Button>
  );
};

export default Bookmark;
interface BookmarkProps {
  isBookmark: boolean;
}

const Button = styled.i<BookmarkProps>`
  width: 40px;
  height: 100%;
  background-size: cover;
  cursor: pointer;
  background: ${({ isBookmark }) =>
      isBookmark === true
        ? "url(/images/icon-Bookmark-filled.svg)"
        : "url(/images/icon-Bookmark-outline.svg)"}
    no-repeat 4.5%;
`;

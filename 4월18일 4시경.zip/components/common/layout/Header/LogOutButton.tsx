import { useCookies } from "react-cookie";
import MoyaLogOutAPI from "../../../../api/login/MoyaLogOutAPI";

const LogOutButton = () => {


  return null
};

export default LogOutButton;

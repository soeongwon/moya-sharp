import LoginService from "../components/LoginService";

const LoginServicePage = () => {
  return (
    <main>
      <LoginService></LoginService>
    </main>
  );
};

export default LoginServicePage
import React from "react";
import { LoginContainer } from "../containers/login/LoginContainer";

export const Login = () => {
  return <LoginContainer />;
};

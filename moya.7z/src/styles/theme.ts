export const theme = {
  primaryColor: "#144056",
  BlueGreenColor: "#48C0B7"
};

export const categories = [
  {
    code: "mp",
    name: "Major"
  },
  {
    code: "op",
    name: "Others"
  },
  {
    code: "r",
    name: "Research"
  },
  {
    code: "mp,op",
    name: "Major&Orhers"
  },
  {
    code: "mp,op,r",
    name: "ALL"
  }
];
